package com.example.EmployeeManagementSystem.projections;


public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
    String getDepartmentName();
}
