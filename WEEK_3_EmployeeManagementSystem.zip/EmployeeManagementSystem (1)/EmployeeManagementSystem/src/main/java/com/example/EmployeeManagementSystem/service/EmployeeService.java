package com.example.EmployeeManagementSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.example.EmployeeManagementSystem.entities.Employee;
import com.example.EmployeeManagementSystem.projections.EmployeeProjection;
import com.example.EmployeeManagementSystem.repository.EmployeeRepository;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Basic CRUD operations
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }
    
    // Custom query methods
    public List<Employee> findEmployeesByName(String name) {
        return employeeRepository.findByName(name);
    }

    public List<Employee> findEmployeesByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }

    public List<Employee> findEmployeesByDepartmentName(String departmentName) {
        return employeeRepository.findByDepartmentName(departmentName);
    }

    public List<Employee> findEmployeesByNameContaining(String name) {
        return employeeRepository.findByNameContaining(name);
    }

    // Pagination and sorting
    public Page<Employee> getEmployeesByNameContaining(String name, int page, int size, String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        return employeeRepository.findByNameContaining(name, pageable);
    }

    // Projections
    public List<EmployeeProjection> getEmployeeProjections() {
        return employeeRepository.findEmployeeProjections();
    }
}
