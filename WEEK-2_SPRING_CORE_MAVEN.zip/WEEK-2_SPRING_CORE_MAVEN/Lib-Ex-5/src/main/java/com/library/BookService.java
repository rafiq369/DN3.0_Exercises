package com.library;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void performService() {
        // Implement service logic here
        System.out.println("Service is performing with injected BookRepository.");
    }
}
